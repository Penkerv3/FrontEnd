// Câu 2: viết JavaScript tại đây

const API_URL = 'http://localhost:4000';

// Hàm có sẵn: đổi giờ UTC sang giờ Việt Nam, vd "08:00 12/09/2026"
const formatDateTime = (iso) =>
  new Date(iso).toLocaleString('vi-VN', {
    timeZone: 'Asia/Ho_Chi_Minh',
    hour: '2-digit', minute: '2-digit',
    day: '2-digit', month: '2-digit', year: 'numeric',
  });

const formatSeats = (event) =>
{
  const left = event.capacity - event.registeredCount;
  if (left <= 0)
  {
    return 'Hết chỗ';
  }
  return `Còn ${left}/${event.capacity} chỗ`;
};

const renderEvents = (events) =>
{
  const eventList = document.querySelector('#event-list');
  
  const cards = events.map((event) =>
  {
    const article = document.createElement('article');
    article.className = 'card';
    const img = document.createElement('img');
    img.setAttribute('src', 'img/event.svg');
    img.setAttribute('alt', event.name);

    const body = document.createElement('div');
    body.className = 'card-body';

    const title = document.createElement('h3');
    const titleLink = document.createElement('a');
    titleLink.setAttribute('href', `event-detail.html?id=${event.id}`);
    titleLink.textContent = event.name;
    title.appendChild(titleLink);

    const timePara = document.createElement('p');
    timePara.className = 'event-time';
    const timeEl = document.createElement('time');
    timeEl.setAttribute('datetime', event.startTime);
    timeEl.textContent = formatDateTime(event.startTime);
    timePara.appendChild(timeEl);

    const locationPara = document.createElement('p');
    locationPara.className = 'event-location';
    locationPara.textContent = event.location;

    const seatsPara = document.createElement('p');
    seatsPara.className = 'event-seats';
    seatsPara.textContent = formatSeats(event);

    body.append(title, timePara, locationPara, seatsPara);

    if (event.registeredCount >= event.capacity)
    {
      const badge = document.createElement('span');
      badge.className = 'badge-danger';
      badge.textContent = 'Hết chỗ';
      body.appendChild(badge);
    }

    article.append(img, body);
    return article;
  });

  eventList.replaceChildren(...cards);
};

const loadEvents = async (keyword = '') =>
{
  const statusEl = document.querySelector('#status');
  const eventList = document.querySelector('#event-list');

  statusEl.textContent = 'Đang tải…';

  const params = new URLSearchParams({ pageSize: '50' });
  const trimmed = keyword.trim();
  if (trimmed !== '')
  {
    params.set('q', trimmed);
  }

  try
  {
    const response = await fetch(`${API_URL}/api/events?${params.toString()}`);
    if (!response.ok)
    {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    const items = data.items || [];

    if (items.length === 0)
    {
      statusEl.textContent = 'Không có sự kiện nào khớp từ khoá.';
      eventList.replaceChildren();
    }

    else
    {
      statusEl.textContent = `Tìm thấy ${data.totalCount ?? items.length} sự kiện`;
      renderEvents(items);
    }
  }

  catch (error)
  {
    statusEl.textContent = 'Không tải được dữ liệu, vui lòng thử lại.';
    eventList.replaceChildren();
  }
};

const searchForm = document.querySelector('#search-form');
const keywordInput = document.querySelector('#keyword');

if (searchForm)
{
  searchForm.addEventListener('submit', (e) =>
  {
    e.preventDefault();
    loadEvents(keywordInput.value);
  });
}

loadEvents();

